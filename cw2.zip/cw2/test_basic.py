#!flask/bin/python
import os
import unittest
import json

from config import basedir
from app import app, db
from app.models import Account

class TestCase(unittest.TestCase):
    def setUp(self):
        app.config['TESTING'] = True
        app.config['WTF_CSRF_ENABLED'] = False
        app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + os.path.join(basedir, 'test.db')
        self.client = app.test_client()
        db.create_all()

    def test_create(self):
        u = Account(username='testuser')
        u.set_password('1212')
        db.session.add(u)
        db.session.commit()

        user = Account.query.filter(Account.username ==
                                         'testuser').first()
        assert user is not None
        db.session.delete(user)
        db.session.commit()

    def test_delete(self):
        u = Account(username='testuser')
        db.session.add(u)
        db.session.commit()

        user = Account.query.filter(Account.username ==
                                    'testuser').first()
        assert user is not None
        db.session.delete(user)
        db.session.commit()
        user = Account.query.filter(Account.username ==
                                    'testuser').first()
        assert user is None

    def test_login(self):
        response = app.test_client().post('/login',data={})
        json_data = response.data.decode()
        json_dict = json.loads(json_data)

        self.assertIn('errcode',json_dict,'typeerror')
        self.assertEqual(json_dict['errcode'],-2,'positionerror')

    def test_logout(self):
        response = app.test_client().post('/login', data={"username": "asd","password": "sss"})
        json_data = response.data.decode()
        json_dict = json.loads(json_data)

        self.assertIn('errcode', json_dict, 'typeerror')
        self.assertEqual(json_dict['errcode'], -1, 'positionerror')

    def tearDown(self):
        db.session.remove()
        db.drop_all()

if __name__ == '__main__':
    unittest.main()
