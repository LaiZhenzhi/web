from flask_wtf import FlaskForm
from wtforms import StringField,PasswordField,BooleanField,SubmitField,DateField,SelectMultipleField,SelectField,TextAreaField
from wtforms.validators import DataRequired,ValidationError,EqualTo
from wtforms.ext.sqlalchemy.fields import QuerySelectField
from app.models import Account,Text,Comment,Kind
#from app.models import Test

class AccountForm(FlaskForm):
    username = StringField('username',validators=[DataRequired(message='please input your username')])
    password = PasswordField('password',validators=[DataRequired(message='please input your password')])
    remember_me = BooleanField('remember me')
    submit = SubmitField('login')

class PasswordForm(FlaskForm):
    old = PasswordField('password', validators=[DataRequired(message='please input your old password')])
    new = PasswordField('password', validators=[DataRequired(message='please input your old password')])
    new_check = PasswordField('check your password',validators=[DataRequired(message='please check your password'), EqualTo('new')])
    submit = SubmitField('change')

class RegisterForm(FlaskForm):
    username = StringField('username', validators=[DataRequired(message='please input your username')])
    name = StringField('name', validators=[DataRequired(message='please input your web name')])
    password = PasswordField('password', validators=[DataRequired(message='please input your password')])
    password_check = PasswordField('check your password', validators=[DataRequired(message='please check your password'),EqualTo('password')])
    submit = SubmitField('register')

    def validate_username(self,username):
        account = Account.query.filter_by(username=username.data).first()
        if account is not None:
            raise ValidationError('failure: repeated username')

class TextForm(FlaskForm):
    title = StringField('title', validators=[DataRequired(message='please input your blog title')])
    content = TextAreaField('content',validators=[DataRequired(message='please input your blog content')])
    show = SelectField('who can see?',validators=[DataRequired()],choices=[('True','All users'),('False','Only me')])
    types = [(g.kindId,g.name) for g in Kind.query.order_by('name')]
    kind = SelectMultipleField('type of the content',validators=[DataRequired()],coerce=int,choices=types)
    submit = SubmitField('publish')

class CommentForm(FlaskForm):
    content = TextAreaField('content', validators=[DataRequired(message='please input your blog content')])
    submit = SubmitField('publish')

class NameForm(FlaskForm):
    name = StringField('new name',validators=[DataRequired(message='please input a new web name')])
    submit = SubmitField('change')

class MasterAccountForm(FlaskForm):
    master = SelectField('Master root',validators=[DataRequired()],choices=[('True','True'),('False','False')])
    submit = SubmitField('confirm')

class NewTypeForm(FlaskForm):
    name = StringField('type', validators=[DataRequired(message='please input a type name')])
    submit = SubmitField('add')