from flask import render_template,flash,redirect,url_for,session,request,g
from app import app,db,admin
from flask_admin.contrib.sqla import ModelView
from app.forms import AccountForm,RegisterForm,NameForm,TextForm,CommentForm,MasterAccountForm,NewTypeForm,PasswordForm
import datetime
from sqlalchemy import or_
#from app.forms import TestForm
from flask_login import current_user,login_user,logout_user,login_required
from app.models import Account,Text,Comment,Kind,Record
import sqlite3
#from app.models import Test
admin.add_view(ModelView(Account, db.session))
admin.add_view(ModelView(Text, db.session))
admin.add_view(ModelView(Kind, db.session))
admin.add_view(ModelView(Record, db.session))

@app.route('/')

#
#homepage
@app.route('/index',methods=['GET','POST'])
def index():
    texts = Text.query.order_by('-textId')
    types = Kind.query.all()
    if current_user.is_authenticated:
        user = Account.query.filter_by(username=current_user.username).first()
        #record the steps
        record = Record(user=current_user.id,
                        date=datetime.datetime.now(),
                        content='(user:'+str(current_user.id)+')'+'/index')
        db.session.add(record)
        db.session.commit()
    else:
        # record the steps
        record = Record(user=-1,
                        date=datetime.datetime.now(),
                        content='(user:-1)'+'/index')
        db.session.add(record)
        db.session.commit()
        user = None
    return render_template('index.html',blog_name='umi',user=user,texts=texts,types=types)

#admin management
@app.route('/admin',methods=['GET','POST'])
@login_required
def admin():
    # record the steps
    record = Record(user=current_user.id,
                    date=datetime.datetime.now(),
                    content='(user:'+str(current_user.id)+')'+'/admin')
    db.session.add(record)
    db.session.commit()
    return "admin"

#selecttype
@app.route('/select_type/<typename>',methods=['GET','POST'])
def select_type(typename):
    # record the steps
    record = Record(user=current_user.id,
                    date=datetime.datetime.now(),
                    content='(user:'+str(current_user.id)+')'+'select_type')
    db.session.add(record)
    db.session.commit()
    types = Kind.query.all()
    typetexts = Kind.query.filter_by(name=typename).first()
    texts = typetexts.havetext
    return render_template('type.html',title=typename,types=types,texts=texts,typename=typename)

#
#login
@app.route('/login',methods=['GET','POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('index'))

    form = AccountForm()

    if form.validate_on_submit():
        account = Account.query.filter_by(username=form.username.data).first()
        if account is None or not account.check_password(form.password.data):
            flash('no such user or wrong password')
            return redirect(url_for('login'))
        login_user(account,remember=form.remember_me.data)
        # record the steps
        record = Record(user=current_user.id,
                        date=datetime.datetime.now(),
                        content='(user:'+str(current_user.id)+')'+'/login')
        db.session.add(record)
        db.session.commit()
        return redirect(url_for('index'))
    return render_template('login.html',title='login',form=form)

#logout
@app.route('/logout')
def logout():
    # record the steps
    record = Record(user=current_user.id,
                    date=datetime.datetime.now(),
                    content='(user:'+str(current_user.id)+')'+'/logout')
    db.session.add(record)
    db.session.commit()
    logout_user()
    flash('Logout successfully!')
    return redirect(url_for('index'))

#registration
@app.route('/register',methods=['GET','POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('index'))

    form = RegisterForm()

    if form.validate_on_submit():
        account = Account(username=form.username.data,
                          name=form.name.data,
                          master='False')
        account.set_password(form.password.data)
        db.session.add(account)
        db.session.commit()
        flash('Welcome! You have been the new user!')
        # record the steps
        record = Record(user=-1,
                        date=datetime.datetime.now(),
                        content='(user:-1)'+'/registration')
        db.session.add(record)
        db.session.commit()
        return redirect(url_for('login'))
    return render_template('register.html',title='register a new account',form=form)

#
#personal page
@app.route('/user/<username>')
@login_required
def user(username):
    # record the steps
    record = Record(user=current_user.id,
                    date=datetime.datetime.now(),
                    content='(user:'+str(current_user.id)+')'+'/user/'+username)
    db.session.add(record)
    db.session.commit()
    account = Account.query.filter_by(username=username).first_or_404()
    texts = account.up_text.order_by('-textId')
    return render_template('user.html',title=username,user=account,username=username,texts=texts)

#password
@app.route('/user/<username>/change_password',methods=['GET','POST'])
@login_required
def change_password(username):
    # record the steps
    record = Record(user=current_user.id,
                    date=datetime.datetime.now(),
                    content='(user:'+str(current_user.id)+')'+'/user/'+username+'/change_password')
    db.session.add(record)
    db.session.commit()
    form = PasswordForm()
    account = Account.query.filter_by(username=username).first_or_404()
    if form.validate_on_submit():
        if account.check_password(form.old.data):
            account.set_password(form.new.data)
            db.session.commit()
            flash('Your password has been changed')
            return redirect(url_for('user', username=username))
        else:
            flash('Wrong old password!')
            return redirect(url_for('change_password', username=username))
    return render_template('change_password.html',title=username,form=form)

#webname
@app.route('/user/<username>/edit_name',methods=['GET','POST'])
@login_required
def edit_name(username):
    # record the steps
    record = Record(user=current_user.id,
                    date=datetime.datetime.now(),
                    content='(user:'+str(current_user.id)+')'+'/user/'+username+'/edit_name')
    db.session.add(record)
    db.session.commit()
    form = NameForm()
    account = Account.query.filter_by(username=username).first_or_404()
    texts = Text.query.filter_by(publisher_username=username)
    comments = Comment.query.filter_by(publisher_username=username)
    if form.validate_on_submit():
        account.name = form.name.data
        for text in texts:
            text.publisher_name = form.name.data
        for comment in comments:
            comment.publisher_name = form.name.data
        db.session.commit()
        return redirect(url_for('user',username=username))
    return render_template('edit_name.html',title=username,user=account,form=form)

#
#new
@app.route('/user/<username>/new_blog',methods=['GET','POST'])
@login_required
def new_blog(username):
    # record the steps
    record = Record(user=current_user.id,
                    date=datetime.datetime.now(),
                    content='(user:'+str(current_user.id)+')'+'/user/'+username+'/new_blog')
    db.session.add(record)
    db.session.commit()
    form = TextForm()
    account = Account.query.filter_by(username=username).first_or_404()
    if form.validate_on_submit():
        content_change=form.content.data
        content_change=content_change.replace('\n','<br>')
        new_text = Text(title=form.title.data,
                        content=content_change,
                        show=form.show.data,
                        like=0,
                        date=datetime.datetime.now(),
                        publisher_username=username)
        for type_id in form.kind.data:
            a_type = Kind.query.get(type_id)
            a_type.havetext.append(new_text)
        account.up_text.append(new_text)
        db.session.add(new_text)
        db.session.commit()
        return redirect(url_for('user', username=username))
    return render_template('new_blog.html',title=username,form=form)

#edit
@app.route('/user/<username>/edit_blog/<textId>',methods=['GET','POST'])
@login_required
def edit_text(username,textId):
    # record the steps
    record = Record(user=current_user.id,
                    date=datetime.datetime.now(),
                    content='(user:'+str(current_user.id)+')'+'/user/'+username+'/edit_blog/'+str(textId))
    db.session.add(record)
    db.session.commit()
    form = TextForm()
    text = Text.query.filter_by(textId=textId).first_or_404()
    if form.validate_on_submit():
        content_change = form.content.data
        content_change = content_change.replace('\n', '<br>')
        text.title = form.title.data
        text.content = content_change
        text.show = form.show.data
        text.date = datetime.datetime.now()
        for old_type in text.havekind:
            text.havekind.remove(old_type)
        for type_id in form.kind.data:
            a_type = Kind.query.get(type_id)
            a_type.havetext.append(text)
        db.session.commit()
        return redirect(url_for('index'))
    return render_template('edit_blog.html',title=textId,form=form,text=text)

#delete
@app.route('/user/<username>/delete_blog/<textId>',methods=['GET','POST'])
@login_required
def delete_text(username,textId):
    # record the steps
    record = Record(user=current_user.id,
                    date=datetime.datetime.now(),
                    content='(user:'+str(current_user.id)+')'+'/delete_blog/'+str(textId))
    db.session.add(record)
    db.session.commit()
    text = Text.query.get(textId)
    for comment in text.has_comment:
        db.session.delete(comment)
    db.session.delete(text)
    db.session.commit()
    return redirect(url_for('user', username=username))

#delete
@app.route('/user/<username>/delete_comment/<commentId>',methods=['GET','POST'])
@login_required
def delete_comment(username,commentId):
    # record the steps
    record = Record(user=current_user.id,
                    date=datetime.datetime.now(),
                    content='(user:'+str(current_user.id)+')'+'/delete_comment/'+str(commentId))
    db.session.add(record)
    db.session.commit()
    comment = Comment.query.get(commentId)
    db.session.delete(comment)
    db.session.commit()
    return redirect(url_for('user', username=username))

#new
@app.route('/write_comment/<textId>',methods=['GET','POST'])
@login_required
def write_comment(textId):
    # record the steps
    record = Record(user=current_user.id,
                    date=datetime.datetime.now(),
                    content='(user:'+str(current_user.id)+')'+'/comment/'+str(textId))
    db.session.add(record)
    db.session.commit()
    form = CommentForm()
    account = Account.query.filter_by(username=current_user.username).first_or_404()
    text = Text.query.get(textId)
    if form.validate_on_submit():
        content_change = form.content.data
        content_change = content_change.replace('\n', '<br>')
        new_comment = Comment(date=datetime.datetime.now(),
                              content=content_change,
                              like=0,
                              publisher_username=current_user.username)
        account.up_commit.append(new_comment)
        text.has_comment.append(new_comment)
        db.session.add(new_comment)
        db.session.commit()
        return redirect(url_for('index'))
    return render_template('new_comment.html',title=current_user.username,form=form,text=text)

#edit
@app.route('/user/<username>/edit_comment/<commentId>',methods=['GET','POST'])
@login_required
def edit_comment(username,commentId):
    # record the steps
    record = Record(user=current_user.id,
                    date=datetime.datetime.now(),
                    content='(user:'+str(current_user.id)+')'+'/edit_comment/'+str(commentId))
    db.session.add(record)
    db.session.commit()
    form = CommentForm()
    comment = Comment.query.get(commentId)
    text = Text.query.get(comment.text_id)
    if form.validate_on_submit():
        content_change = form.content.data
        content_change = content_change.replace('\n', '<br>')
        comment.date = datetime.datetime.now()
        comment.content = content_change
        db.session.commit()
        return redirect(url_for('index'))
    return render_template('new_comment.html', title=current_user.username, form=form,text=text,comment=comment)

#
#master management
@app.route('/master_management/<master_username>')
@login_required
def master_management(master_username):
    # record the steps
    record = Record(user=current_user.id,
                    date=datetime.datetime.now(),
                    content='(user:'+str(current_user.id)+')'+'/master_management')
    db.session.add(record)
    db.session.commit()
    return render_template('master_management.html',title=current_user.username)

@app.route('/master_management/<master_username>/accounts',methods=['GET','POST'])
@login_required
def all_accounts(master_username):
    # record the steps
    record = Record(user=current_user.id,
                    date=datetime.datetime.now(),
                    content='(user:'+str(current_user.id)+')'+'/master_management/accounts')
    db.session.add(record)
    db.session.commit()
    accounts = Account.query.all()
    return render_template('master_accounts.html', title=current_user.username,accounts=accounts)

@app.route('/master_management/<master_username>/accounts/delete/<id>',methods=['GET','POST'])
@login_required
def master_delete_account(master_username,id):
    # record the steps
    record = Record(user=current_user.id,
                    date=datetime.datetime.now(),
                    content='(user:'+str(current_user.id)+')'+'/master_management/accounts_delete/'+str(id))
    db.session.add(record)
    db.session.commit()
    account = Account.query.get(id)
    for up_text in account.up_text:
        for comment in up_text.has_comment:
            db.session.delete(comment)
        db.session.delete(up_text)
    for a_commit in account.up_commit:
        db.session.delete(a_commit)
    db.session.delete(account)
    db.session.commit()
    accounts = Account.query.all()
    return render_template('master_accounts.html', title=current_user.username, accounts=accounts)

@app.route('/master_management/<master_username>/<id>',methods=['GET','POST'])
@login_required
def master_account(master_username,id):
    # record the steps
    record = Record(user=current_user.id,
                    date=datetime.datetime.now(),
                    content='(user:'+str(current_user.id)+')'+'/master_management/accounts_change_master_root'+str(id))
    db.session.add(record)
    db.session.commit()
    form = MasterAccountForm()
    account = Account.query.get(id)
    if form.validate_on_submit():
        account.master = form.master.data
        db.session.commit()
        return redirect(url_for('all_accounts',master_username=current_user.username))
    return render_template('master_accounts_root.html',title=current_user.username,form=form)

@app.route('/master_management/<master_username>/texts',methods=['GET','POST'])
@login_required
def all_texts(master_username):
    # record the steps
    record = Record(user=current_user.id,
                    date=datetime.datetime.now(),
                    content='(user:'+str(current_user.id)+')'+'/master_management/texts')
    db.session.add(record)
    db.session.commit()
    texts = Text.query.all()
    return render_template('master_texts.html', title=current_user.username,texts=texts)

@app.route('/master_management/<master_username>/texts/comments/<textId>',methods=['GET','POST'])
@login_required
def text_comment(master_username,textId):
    # record the steps
    record = Record(user=current_user.id,
                    date=datetime.datetime.now(),
                    content='(user:'+str(current_user.id)+')'+'/master_management/texts/comment')
    db.session.add(record)
    db.session.commit()
    text = Text.query.get(textId)
    return render_template('master_texts_comments.html', title=current_user.username,text=text,textId=textId)

@app.route('/master_management/<master_username>/texts/comments/<textId>/delete/<commentId>',methods=['GET','POST'])
@login_required
def master_delete_comment_in_account(master_username,textId,commentId):
    # record the steps
    record = Record(user=current_user.id,
                    date=datetime.datetime.now(),
                    content='(user:'+str(current_user.id)+')'+'/master_management/comment_delete/'+str(commentId))
    db.session.add(record)
    db.session.commit()
    comment = Comment.query.get(commentId)
    db.session.delete(comment)
    db.session.commit()
    text = Text.query.get(textId)
    return render_template('master_texts_comments.html', title=current_user.username,text=text,textId=textId)

@app.route('/master_management/<master_username>/texts/delete/<textId>',methods=['GET','POST'])
@login_required
def master_delete_text(master_username,textId):
    # record the steps
    record = Record(user=current_user.id,
                    date=datetime.datetime.now(),
                    content='(user:'+str(current_user.id)+')'+'/master_management/text_delete/'+str(textId))
    db.session.add(record)
    db.session.commit()
    text = Text.query.get(textId)
    for comment in text.has_comment:
        db.session.delete(comment)
    db.session.delete(text)
    db.session.commit()
    texts = Text.query.all()
    return render_template('master_texts.html', title=current_user.username, texts=texts)

@app.route('/master_management/<master_username>/comments',methods=['GET','POST'])
@login_required
def all_comments(master_username):
    # record the steps
    record = Record(user=current_user.id,
                    date=datetime.datetime.now(),
                    content='(user:'+str(current_user.id)+')'+'/master_management/comments')
    db.session.add(record)
    db.session.commit()
    comments = Comment.query.all()
    return render_template('master_comments.html', title=current_user.username,comments=comments)

@app.route('/master_management/<master_username>/comments/delete/<commentId>',methods=['GET','POST'])
@login_required
def master_delete_comment(master_username,commentId):
    # record the steps
    record = Record(user=current_user.id,
                    date=datetime.datetime.now(),
                    content='(user:'+str(current_user.id)+')'+'/master_management/comments_delete/'+str(commentId))
    db.session.add(record)
    db.session.commit()
    comment = Comment.query.get(commentId)
    db.session.delete(comment)
    db.session.commit()
    comments = Comment.query.all()
    return render_template('master_comments.html', title=current_user.username, comments=comments)

@app.route('/master_management/<master_username>/kinds',methods=['GET','POST'])
@login_required
def all_kinds(master_username):
    # record the steps
    record = Record(user=current_user.id,
                    date=datetime.datetime.now(),
                    content='(user:'+str(current_user.id)+')'+'/master_management/kinds')
    db.session.add(record)
    db.session.commit()
    kinds = Kind.query.all()
    return render_template('master_kinds.html', title=current_user.username,kinds=kinds)

@app.route('/master_management/<master_username>/kinds/addkind',methods=['GET','POST'])
@login_required
def new_kind(master_username):
    form = NewTypeForm()
    if form.validate_on_submit():
        kind = Kind(name=form.name.data)
        db.session.add(kind)
        db.session.commit()
        # record the steps
        record = Record(user=current_user.id,
                        date=datetime.datetime.now(),
                        content='(user:'+str(current_user.id)+')'+'/master_management/kinds_add/' + str(kind.kindId))
        db.session.add(record)
        db.session.commit()
        return redirect(url_for('all_kinds',master_username=current_user.username))
    return render_template('new_kind.html', title=current_user.username,form=form)

@app.route('/master_management/<master_username>/kinds/delete/<kindId>',methods=['GET','POST'])
@login_required
def master_delete_kind(master_username,kindId):
    # record the steps
    record = Record(user=current_user.id,
                    date=datetime.datetime.now(),
                    content='(user:'+str(current_user.id)+')'+'/master_management/kinds_delete/' + str(kindId))
    db.session.add(record)
    db.session.commit()
    kind = Kind.query.get(kindId)
    db.session.delete(kind)
    db.session.commit()
    kinds = Kind.query.all()
    return render_template('master_kinds.html', title=current_user.username, kinds=kinds)

@app.route('/index/<username>/delete_blog/<textId>',methods=['GET','POST'])
@login_required
def delete_text_index(username,textId):
    # record the steps
    record = Record(user=current_user.id,
                    date=datetime.datetime.now(),
                    content='(user:'+str(current_user.id)+')'+'/delete_text/' + str(textId))
    db.session.add(record)
    db.session.commit()
    text = Text.query.get(textId)
    for comment in text.has_comment:
        db.session.delete(comment)
    db.session.delete(text)
    db.session.commit()
    return redirect(url_for('index'))

@app.route('/index/<username>/delete_comment/<commentId>',methods=['GET','POST'])
@login_required
def delete_comment_index(username,commentId):
    # record the steps
    record = Record(user=current_user.id,
                    date=datetime.datetime.now(),
                    content='(user:'+str(current_user.id)+')'+'/delete_comment/' + str(commentId))
    db.session.add(record)
    db.session.commit()
    comment = Comment.query.get(commentId)
    db.session.delete(comment)
    db.session.commit()
    return redirect(url_for('index'))

#
#like/dislike
@app.route('/index/text/<username>/like/<textId>',methods=['GET','POST'])
@login_required
def like_text_index(username,textId):
    # record the steps
    record = Record(user=current_user.id,
                    date=datetime.datetime.now(),
                    content='(user:'+str(current_user.id)+')'+'/like/' + str(textId))
    db.session.add(record)
    db.session.commit()
    text = Text.query.get(textId)
    text.like = text.like + 1
    db.session.commit()
    return redirect(url_for('index'))

@app.route('/index/text/<username>/dislike/<textId>',methods=['GET','POST'])
@login_required
def dislike_text_index(username,textId):
    # record the steps
    record = Record(user=current_user.id,
                    date=datetime.datetime.now(),
                    content='(user:'+str(current_user.id)+')'+'/dislike/' + str(textId))
    db.session.add(record)
    db.session.commit()
    text = Text.query.get(textId)
    text.like = text.like - 1
    db.session.commit()
    return redirect(url_for('index'))

@app.route('/index/comment/<username>/like/<commentId>',methods=['GET','POST'])
@login_required
def like_comment_index(username,commentId):
    # record the steps
    record = Record(user=current_user.id,
                    date=datetime.datetime.now(),
                    content='(user:'+str(current_user.id)+')'+'/like/' + str(commentId))
    db.session.add(record)
    db.session.commit()
    comment = Comment.query.get(commentId)
    comment.like = comment.like + 1
    db.session.commit()
    return redirect(url_for('index'))

@app.route('/index/comment/<username>/dislike/<commentId>',methods=['GET','POST'])
@login_required
def dislike_comment_index(username,commentId):
    # record the steps
    record = Record(user=current_user.id,
                    date=datetime.datetime.now(),
                    content='(user:'+str(current_user.id)+')'+'/dislike/' + str(commentId))
    db.session.add(record)
    db.session.commit()
    comment = Comment.query.get(commentId)
    comment.like = comment.like - 1
    db.session.commit()
    return redirect(url_for('index'))

@app.route('/user/text/<username>/like/<textId>',methods=['GET','POST'])
@login_required
def like_text_user(username,textId):
    # record the steps
    record = Record(user=current_user.id,
                    date=datetime.datetime.now(),
                    content='(user:'+str(current_user.id)+')'+'/like/' + str(textId))
    db.session.add(record)
    db.session.commit()
    text = Text.query.get(textId)
    text.like = text.like + 1
    db.session.commit()
    return redirect(url_for('user', username=username))

@app.route('/user/text/<username>/dislike/<textId>',methods=['GET','POST'])
@login_required
def dislike_text_user(username,textId):
    # record the steps
    record = Record(user=current_user.id,
                    date=datetime.datetime.now(),
                    content='(user:'+str(current_user.id)+')'+'/dislike/' + str(textId))
    db.session.add(record)
    db.session.commit()
    text = Text.query.get(textId)
    text.like = text.like - 1
    db.session.commit()
    return redirect(url_for('user', username=username))

@app.route('/user/comment/<username>/like/<commentId>',methods=['GET','POST'])
@login_required
def like_comment_user(username,commentId):
    # record the steps
    record = Record(user=current_user.id,
                    date=datetime.datetime.now(),
                    content='(user:'+str(current_user.id)+')'+'/like/' + str(commentId))
    db.session.add(record)
    db.session.commit()
    comment = Comment.query.get(commentId)
    comment.like = comment.like + 1
    db.session.commit()
    return redirect(url_for('user', username=username))

@app.route('/user/comment/<username>/dislike/<commentId>',methods=['GET','POST'])
@login_required
def dislike_comment_user(username,commentId):
    # record the steps
    record = Record(user=current_user.id,
                    date=datetime.datetime.now(),
                    content='(user:'+str(current_user.id)+')'+'/dislike/' + str(commentId))
    db.session.add(record)
    db.session.commit()
    comment = Comment.query.get(commentId)
    comment.like = comment.like - 1
    db.session.commit()
    return redirect(url_for('user', username=username))

@app.route('/search/',methods=['GET','POST'])
def search():
    key = request.form.get("key")
    print(key)
    search_texts = Text.query.filter(or_(Text.title.contains(key),Text.content.contains(key))).order_by('-textId')
    # record the steps
    record = Record(user=current_user.id,
                    date=datetime.datetime.now(),
                    content='search')
    db.session.add(record)
    db.session.commit()
    types = Kind.query.all()
    if current_user.is_authenticated:
        user = Account.query.filter_by(username=current_user.username).first()
        # record the steps
        record = Record(user=current_user.id,
                        date=datetime.datetime.now(),
                        content='(user:' + str(current_user.id) + ')' + '/index')
        db.session.add(record)
        db.session.commit()
    else:
        # record the steps
        record = Record(user=-1,
                        date=datetime.datetime.now(),
                        content='(user:-1)' + '/index')
        db.session.add(record)
        db.session.commit()
        user = None
    return render_template('search.html', blog_name='umi', user=user, texts=search_texts, types=types)