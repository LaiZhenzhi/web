from app import db
from werkzeug.security import generate_password_hash, check_password_hash
from flask_login import UserMixin
from app import login

enrollment = db.Table('enrollment', db.Model.metadata,
    db.Column('kindId', db.Integer, db.ForeignKey('kind.kindId')),
    db.Column('textId', db.Integer, db.ForeignKey('text.textId'))
)

class Account(UserMixin,db.Model):
    id = db.Column(db.Integer,primary_key=True)
    username = db.Column(db.String(20),unique=True)
    name = db.Column(db.String(20),unique=True)
    password_hash = db.Column(db.String(128))
    master = db.Column(db.String(6))
    up_text = db.relationship('Text',backref='account',lazy='dynamic')
    up_commit = db.relationship('Comment',backref='account',lazy='dynamic')

    def __repr__(self):
        return self.username

    def set_password(self,password):
        self.password_hash = generate_password_hash(password)

    def check_password(self,password):
        return check_password_hash(self.password_hash,password)

@login.user_loader
def load_account(id):
    #return Account.query.get(id)
    return Account.query.get(int(id))

class Kind(db.Model):
    kindId = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(20))
    havetext = db.relationship('Text',secondary=enrollment)

    def __repr__(self):
        return self.kindId

class Text(db.Model):
    textId = db.Column(db.Integer,primary_key=True)
    date = db.Column(db.Date)
    title = db.Column(db.String(100))
    content = db.Column(db.String(5000))
    show = db.Column(db.String(6))
    like = db.Column(db.Integer)
    havekind = db.relationship('Kind',secondary=enrollment)
    has_comment = db.relationship('Comment',backref='text',lazy='dynamic')
    publisher_name = db.Column(db.String(20),db.ForeignKey('account.name'))
    publisher_username =db.Column(db.String(20))

    def __repr__(self):
        return self.textId

class Comment(db.Model):
    commentId = db.Column(db.Integer,primary_key=True)
    date = db.Column(db.Date)
    content = db.Column(db.String(2000))
    like = db.Column(db.Integer)
    text_id = db.Column(db.Integer,db.ForeignKey('text.textId'))
    publisher_name = db.Column(db.String(20),db.ForeignKey('account.name'))
    publisher_username = db.Column(db.String(20))

    def __repr__(self):
        return self.commentId

class Record(db.Model):
    recordId = db.Column(db.Integer,primary_key=True)
    user = db.Column(db.Integer, db.ForeignKey('account.id'))
    date = db.Column(db.Date)
    content = db.Column(db.String(2000))

    def __repr__(self):
        return self.recordId
